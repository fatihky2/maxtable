./sample_ins_10000 &
./sample_ins_20000 &
./sample_ins_30000 &
./sample_ins_40000 &
./sample_ins_50000 &


